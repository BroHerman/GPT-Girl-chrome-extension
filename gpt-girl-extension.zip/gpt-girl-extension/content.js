(function () {
  'use strict';


  // -------- Theme helper: only check ChatGPT's own theme --------
  function isChatGPTDark() {
    const docEl = document.documentElement;
    const body = document.body;

    if (!docEl) return false;

    // 1) <html class="dark"> 或 <body class="dark">
    if (
      docEl.classList.contains('dark') ||
      (body && body.classList.contains('dark'))
    ) {
      return true;
    }

    // 2) <html data-theme="dark"> / data-theme="light"
    const themeAttr =
      docEl.getAttribute('data-theme') ||
      (docEl.dataset && docEl.dataset.theme) ||
      '';

    if (themeAttr.toLowerCase().includes('dark')) {
      return true;
    }

    return false;
  }



  // -------- Theme helper --------

  function isDarkTheme() {
    const docEl = document.documentElement;
    if (!docEl) return false;

    // ChatGPT often uses a .dark class on <html>
    if (docEl.classList.contains('dark')) return true;

    // Or data-theme / data-color-mode style attributes
    const themeAttr =
      docEl.getAttribute('data-theme') ||
      (docEl.dataset && (docEl.dataset.theme || docEl.dataset.colorMode));

    if (themeAttr && String(themeAttr).toLowerCase().includes('dark')) {
      return true;
    }

    // Fallback to system preference
    if (
      window.matchMedia &&
      window.matchMedia('(prefers-color-scheme: dark)').matches
    ) {
      return true;
    }

    return false;
  }

  // -------- Assets --------

  const IDLE_URL =
    'https://cdn.jsdelivr.net/gh/BroHerman/GPT-Girl@main/idle.gif';
  const THINK_URL =
    'https://cdn.jsdelivr.net/gh/BroHerman/GPT-Girl@main/think.gif';
  const ANSWER_URL =
    'https://cdn.jsdelivr.net/gh/BroHerman/GPT-Girl@main/type.gif';

  const MUSIC_URL =
    'https://cdn.jsdelivr.net/gh/BroHerman/GPT-Girl@main/debussy-arabesque-no-1.mp3';

  // -------- Background state --------

  let bgState = 'idle'; // 'idle' | 'thinking' | 'answering'
  let lastAssistantTime = 0;
  let lastAssistantWithStop = false;

  let bgEnabled = true;
  let bgBtn = null;

  let lastThemeIsDark = null;

  // -------- Music state --------

  let audioCtx = null;
  let audioBuffer = null;
  let musicLoading = false;
  let musicLoadError = null;
  let musicPlaying = false;
  let currentSource = null;
  let musicBtn = null;

  // -------- Styles --------

  function injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
      #gpt-girl-panel {
        position: fixed;
        right: 24px;
        bottom: 24px;
        z-index: 9999;
        display: flex;
        gap: 8px;
        align-items: center;
      }

      /* Base button styles */
      .gpt-girl-btn,
      .gpt-music-btn {
        padding: 6px 12px;
        border-radius: 999px;
        font: inherit;
        font-size: 12px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        border-width: 1px;
        border-style: solid;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        transition:
          background-color 0.2s ease,
          color 0.2s ease,
          border-color 0.2s ease,
          box-shadow 0.2s ease;
      }

      .gpt-girl-btn span.dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #22c55e;
      }

      .gpt-music-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: 50%;
      }

      .gpt-music-btn .music-icon {
        font-size: 15px;
        line-height: 1;
      }

      /* -------- Dark theme appearance -------- */
      html.dark .gpt-girl-btn,
      :root[data-theme="dark"] .gpt-girl-btn,
      html.dark .gpt-music-btn,
      :root[data-theme="dark"] .gpt-music-btn {
        background: rgba(32, 32, 32, 0.9);
        color: #f5f5f5;
        border-color: rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 12px rgba(0,0,0,0.4);
      }

      html.dark .gpt-girl-btn.off,
      :root[data-theme="dark"] .gpt-girl-btn.off,
      html.dark .gpt-music-btn.off,
      :root[data-theme="dark"] .gpt-music-btn.off {
        background: rgba(15, 23, 42, 0.8);
        color: #a1a1aa;
        border-color: rgba(148, 163, 184, 0.5);
      }

      html.dark .gpt-girl-btn.off span.dot,
      :root[data-theme="dark"] .gpt-girl-btn.off span.dot {
        background: #9ca3af;
      }

      /* -------- Light theme appearance -------- */
      html:not(.dark) .gpt-girl-btn,
      :root:not([data-theme="dark"]) .gpt-girl-btn,
      html:not(.dark) .gpt-music-btn,
      :root:not([data-theme="dark"]) .gpt-music-btn {
        background: rgba(255, 255, 255, 0.96);
        color: #111827;
        border-color: rgba(0, 0, 0, 0.08);
        box-shadow: 0 4px 12px rgba(15,23,42,0.12);
      }

      html:not(.dark) .gpt-girl-btn.off,
      :root:not([data-theme="dark"]) .gpt-girl-btn.off,
      html:not(.dark) .gpt-music-btn.off,
      :root:not([data-theme="dark"]) .gpt-music-btn.off {
        background: rgba(249, 250, 251, 0.96);
        color: #6b7280;
        border-color: rgba(156, 163, 175, 0.6);
      }

      html:not(.dark) .gpt-girl-btn.off span.dot,
      :root:not([data-theme="dark"]) .gpt-girl-btn.off span.dot {
        background: #9ca3af;
      }
    `;
    document.head.appendChild(style);
  }

  // -------- Background helpers --------

  function clearBackground() {
    if (!document.body) return;
    const s = document.body.style;
    s.backgroundImage = '';
    s.backgroundColor = '';
    s.backgroundBlendMode = '';
    s.backgroundSize = '';
    s.backgroundPosition = '';
    s.backgroundRepeat = '';
    s.backgroundAttachment = '';
  }

  function setBodyBackground(url) {
    if (!document.body || !bgEnabled) return;
    const s = document.body.style;
    const dark = isChatGPTDark();

    s.backgroundImage = `url("${url}")`;
    s.backgroundSize = 'auto 100vh';
    s.backgroundPosition = 'center center';
    s.backgroundRepeat = 'no-repeat';
    s.backgroundAttachment = 'fixed';

    if (dark) {
      // DARK 模式：背景图 + 半透明黑遮罩
      s.backgroundColor = 'rgba(0, 0, 0, 0.50)';
      s.backgroundBlendMode = 'darken';   // 图像被压暗，白字可见
    } else {
      // LIGHT 模式：背景图 + 半透明白遮罩
      s.backgroundColor = 'rgba(255, 255, 255, 0.65)';
      s.backgroundBlendMode = 'lighten';  // 图像被提亮，黑字不会淹没在黑发里
    }
  }


  function renderCurrentBackground() {
    if (!bgEnabled) return;
    if (bgState === 'idle') setBodyBackground(IDLE_URL);
    else if (bgState === 'thinking') setBodyBackground(THINK_URL);
    else if (bgState === 'answering') setBodyBackground(ANSWER_URL);
  }

  function setBgState(newState) {
    if (bgState === newState) return;
    bgState = newState;
    renderCurrentBackground();
  }

  function hasStopButton() {
    return !!document.querySelector(
      [
        'button[data-testid*="stop"]',
        'button[data-testid*="abort"]',
        'button[aria-label*="Stop"]',
        'button[aria-label*="停止"]',
        'button[aria-label*="终止"]'
      ].join(',')
    );
  }

  function isInsideAssistant(node) {
    if (!node) return false;
    let el = node.nodeType === 1 ? node : node.parentElement;
    while (el) {
      if (
        el.getAttribute &&
        el.getAttribute('data-message-author-role') === 'assistant'
      ) {
        return true;
      }
      el = el.parentElement;
    }
    return false;
  }

  // -------- Music (WebAudio) --------

  function ensureAudioContext() {
    if (!audioCtx) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return null;
      audioCtx = new Ctx();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function updateMusicButtonUI() {
    if (!musicBtn) return;
    const icon = musicBtn.querySelector('.music-icon');
    if (!icon) return;

    if (musicLoading) {
      icon.textContent = '…'; // loading
      musicBtn.classList.remove('off');
      musicBtn.setAttribute('aria-pressed', 'true');
    } else if (musicLoadError) {
      icon.textContent = '⚠'; // error
      musicBtn.classList.add('off');
      musicBtn.setAttribute('aria-pressed', 'false');
    } else if (musicPlaying) {
      icon.textContent = '||'; // playing (pause)
      musicBtn.classList.remove('off');
      musicBtn.setAttribute('aria-pressed', 'true');
    } else {
      icon.textContent = '▶'; // ready to play
      musicBtn.classList.add('off');
      musicBtn.setAttribute('aria-pressed', 'false');
    }
  }

  function loadTrackIfNeeded() {
    if (audioBuffer || musicLoading || musicLoadError) return;

    musicLoading = true;
    updateMusicButtonUI();

    fetch(MUSIC_URL)
      .then((resp) => {
        if (!resp.ok) {
          throw new Error('HTTP ' + resp.status);
        }
        return resp.arrayBuffer();
      })
      .then((buf) => {
        const ctx = ensureAudioContext();
        if (!ctx) {
          throw new Error('No AudioContext');
        }
        return ctx.decodeAudioData(buf);
      })
      .then((decoded) => {
        audioBuffer = decoded;
        musicLoading = false;
        musicLoadError = null;
        updateMusicButtonUI();
        if (!musicPlaying) {
          startMusicPlayback();
        }
      })
      .catch((err) => {
        musicLoading = false;
        musicLoadError = err;
        updateMusicButtonUI();
        console.error('[GPT-Girl] LoFi load error:', err);
      });
  }

  function startMusicPlayback() {
    if (!audioBuffer) {
      loadTrackIfNeeded();
      return;
    }
    const ctx = ensureAudioContext();
    if (!ctx) return;

    if (currentSource) {
      try {
        currentSource.stop();
      } catch (_) {}
      try {
        currentSource.disconnect();
      } catch (_) {}
    }

    const source = ctx.createBufferSource();
    const gain = ctx.createGain();
    source.buffer = audioBuffer;
    source.loop = true;
    gain.gain.value = 0.35;

    source.connect(gain);
    gain.connect(ctx.destination);

    source.start(0);
    currentSource = source;
    musicPlaying = true;
    updateMusicButtonUI();
  }

  function stopMusicPlayback() {
    if (currentSource) {
      try {
        currentSource.stop();
      } catch (_) {}
      try {
        currentSource.disconnect();
      } catch (_) {}
      currentSource = null;
    }
    musicPlaying = false;
    updateMusicButtonUI();
  }

  function toggleMusicPlayback() {
    if (!audioBuffer && !musicLoading && !musicLoadError) {
      startMusicPlayback();
      return;
    }
    if (musicLoading) {
      return;
    }
    if (musicLoadError) {
      audioBuffer = null;
      musicLoadError = null;
      startMusicPlayback();
      return;
    }
    if (musicPlaying) {
      stopMusicPlayback();
    } else {
      startMusicPlayback();
    }
  }

  // -------- Panel & buttons --------

  function createPanelAndButtons() {
    if (!document.body) return;

    let panel = document.getElementById('gpt-girl-panel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'gpt-girl-panel';
      document.body.appendChild(panel);
    }

    // GPT-Girl background toggle (pill)
    if (!document.getElementById('gpt-girl-toggle')) {
      bgBtn = document.createElement('button');
      bgBtn.id = 'gpt-girl-toggle';
      bgBtn.type = 'button';
      bgBtn.className = 'gpt-girl-btn';
      bgBtn.innerHTML = `<span class="dot"></span><span>GPT-Girl</span>`;
      bgBtn.setAttribute('aria-pressed', 'true');

      const updateBgBtnStyle = () => {
        if (bgEnabled) {
          bgBtn.classList.remove('off');
          bgBtn.setAttribute('aria-pressed', 'true');
        } else {
          bgBtn.classList.add('off');
          bgBtn.setAttribute('aria-pressed', 'false');
        }
      };

      bgBtn.addEventListener('click', () => {
        bgEnabled = !bgEnabled;
        updateBgBtnStyle();
        if (!bgEnabled) clearBackground();
        else renderCurrentBackground();
      });

      updateBgBtnStyle();
      panel.appendChild(bgBtn);
    } else {
      bgBtn = document.getElementById('gpt-girl-toggle');
    }

    // Round music button
    if (!document.getElementById('gpt-girl-music')) {
      musicBtn = document.createElement('button');
      musicBtn.id = 'gpt-girl-music';
      musicBtn.type = 'button';
      musicBtn.className = 'gpt-music-btn off';
      musicBtn.innerHTML = `<span class="music-icon">▶</span>`;
      musicBtn.setAttribute('aria-pressed', 'false');

      musicBtn.addEventListener('click', () => {
        toggleMusicPlayback();
      });

      panel.appendChild(musicBtn);
    } else {
      musicBtn = document.getElementById('gpt-girl-music');
    }

    updateMusicButtonUI();
  }

  // -------- Init & background state machine --------

  function init() {
    if (!document.body) {
      setTimeout(init, 300);
      return;
    }

    injectStyles();
    createPanelAndButtons();

    // initial idle background
    renderCurrentBackground();

    lastThemeIsDark = isChatGPTDark();

    const observer = new MutationObserver((mutations) => {
      const now = Date.now();
      let assistantActivity = false;

      for (const m of mutations) {
        if (m.type === 'childList') {
          m.addedNodes.forEach((n) => {
            if (isInsideAssistant(n)) assistantActivity = true;
          });
        } else if (m.type === 'characterData') {
          if (isInsideAssistant(m.target)) assistantActivity = true;
        }
      }

      if (!assistantActivity) return;

      const stopNow = hasStopButton();
      lastAssistantTime = now;
      lastAssistantWithStop = stopNow;

      if (stopNow) {
        setBgState('answering');
      } else if (bgState !== 'answering') {
        setBgState('thinking');
      }
    });

    observer.observe(document.body, {
      childList: true,
      characterData: true,
      subtree: true
    });

        setInterval(() => {
      const now = Date.now();

      // --- 检测主题是否切换（light <-> dark） ---
      const currentDark = isChatGPTDark();
      if (lastThemeIsDark === null) {
        lastThemeIsDark = currentDark;
      } else if (currentDark !== lastThemeIsDark) {
        // 主题发生了变化：立刻重新渲染当前背景（同一张图 + 新颜色遮罩）
        lastThemeIsDark = currentDark;
        if (bgEnabled) {
          renderCurrentBackground();
        }
      }

      const stopNow = hasStopButton();
      const dt = now - lastAssistantTime;

      if (stopNow) {
        // stop button visible: we are either answering or waiting
        if (dt < 300 && lastAssistantWithStop) {
          setBgState('answering');
        } else {
          setBgState('thinking');
        }
      } else {
        // no stop button: either just finished answer / history, or fully idle
        if (dt < 800) {
          if (lastAssistantWithStop) {
            setBgState('answering');
          } else {
            setBgState('thinking');
          }
        } else {
          setBgState('idle');
        }
      }
    }, 300);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
